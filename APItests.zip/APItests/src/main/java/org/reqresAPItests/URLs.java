package org.reqresAPItests;

public enum URLs {

}
